package big_data.bit.exall;

public class P207Ex11 {
	public static void printArray(int[] n) {
		for(int i = 0; i < n.length; i++) {
			System.out.println(n[i] + " ");
		}
	}

	public static void main(String[] args) {
		printArray(new int[] {1,2,3,4});
	}
}
