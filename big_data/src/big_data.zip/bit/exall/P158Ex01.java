package big_data.bit.exall;

// 1. 프린터 객채 생성
// 2. 프린터에 용지 100장 추가
// 3. 프린터로 70장 출력
// 4. 프린터 남아있는 용지

public class P158Ex01 {
//	public static void main(String[] args) {
//		Printer p = new Printer();
//		p.numOfPapers = 100;
//		p.print(70);
//		System.out.println(p.numOfPapers);
//		
//	}
}
