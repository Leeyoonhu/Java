package big_data.bit.exall;

public class P79Ex16 {
	public static void main(String[] args) {
		int i = 0x11, i2 = 5;
		final int ONE = 1;
		char c1 = 'a';
		float f1 = 1.5f;
		double d1 = 2.8;
		boolean b1 = true;
		
		//i1 = 0x11
		//i1/2 = 0x11/2
		//c1 + ONE = a1
		//(int)c1 + ONE = 98
		//(c1 + ONE) = 98
		//(c1 + ONE) = b
		//
		//
		//
		//
	}
}
