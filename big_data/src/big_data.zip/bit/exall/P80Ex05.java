package big_data.bit.exall;

public class P80Ex05 {
	public static void main(String[] args) {
		//임의로 초기화된 char 타입 c 대문자 변환 출력프로그램 작성
		char c = 'a';
		c += (int)'A' - (int)'a';
		System.out.println(c);
	}
}
