package big_data.bit.exall;

public class P124Ex08 {
	public static void main(String[] args) {
		// 개선된 switch문은 jdk 14버전부터 지원
		// 풀이x
	}
}
