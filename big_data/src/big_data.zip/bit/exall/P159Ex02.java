package big_data.bit.exall;

// Ex01에서 프린터의 용지가 부족할 수도 있다. 
// numOfPapers 필드를 private로 변경, 초기화 생성자 추가
// print() 메서드에 기능 추가
// 1. 출력할때 남아있는 용지가 없으면 없다 알림
// 2. 남아있는 용지보다 많은 출력을 요구하면 남아있는 용지만큼 출력하고 모자란 출력 알림
// 3. 출력 후 남아있는 용지 알림


public class P159Ex02 {
//	public static void main(String[] args) {
//		Printer p = new Printer(10);
//		p.print(2);
//		p.print(20);
//		p.print(10);
//	}
}
