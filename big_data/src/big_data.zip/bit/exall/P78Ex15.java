package big_data.bit.exall;

public class P78Ex15 {
	public static void main(String[] args) {
		// 100부터 200
		// 200 년 전
		// 200100 어이쿠!
		int x = 100;
		System.out.println(x + "부터 " + 200);
		System.out.println(x + 100 + " 년 전");
		System.out.println("200" + "100" + " 어이쿠!");
	}
}
