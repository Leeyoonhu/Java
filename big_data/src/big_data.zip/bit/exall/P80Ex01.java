package big_data.bit.exall;

public class P80Ex01 {
	public static void main(String[] args) {
		// println()메서드를 이용해 피라미드 출력
		System.out.println("     *");
		System.out.println("    ***");
		System.out.println("   *****");
		System.out.println("  *******");
		System.out.println(" *********");
		System.out.println("***********");
		}
}
