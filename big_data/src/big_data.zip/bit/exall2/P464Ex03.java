package big_data.bit.exall2;

import java.util.Arrays;
import java.util.List;

public class P464Ex03 {
	public static void main(String[] args) {
		//2번 문제에서 한글단어 추출후 단어를 섞고 출력하는 실행문 작성
		String[] s = { "사과", "바나나" };
		List<String> list = Arrays.asList(s);

		
	}
}
