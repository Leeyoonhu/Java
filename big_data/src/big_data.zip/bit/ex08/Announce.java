package big_data.bit.ex08;

public class Announce {
	// Collection => List / Set / Queue      /////  Map
	// 1. List >> ArrayList(add, get), LinkedList(add, get), Stack(push, pop)
	// 2. Set >> HashSet(add, get), TreeSet(add, get)
	// 3. Map >> HashMap(put(key, value), get(key)), TreeMap(put(key, value), get(key))
	
}
