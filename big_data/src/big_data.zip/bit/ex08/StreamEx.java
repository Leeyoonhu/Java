package big_data.bit.ex08;

public class StreamEx {
	public static void main(String[] args) {
		// 단방향 흐름을 추상화 한것
		// InputStream, OutputStream이 모든 스트림의 조상, byte단위로 처리
	}
}
