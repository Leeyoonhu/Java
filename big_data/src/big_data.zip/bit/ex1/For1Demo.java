package big_data.bit.ex1;

public class For1Demo {
	public static void main(String[] args) {
		for(int i = 1; i < 5; i++) {
			System.out.print(i);
		}
		
//		System.out.println(i);  몸체 밖에서 i를 호출할 수 없음 
	}
}
