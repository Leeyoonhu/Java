package big_data.bit.ex1;

interface Printable{
	String toner = "";
	abstract void print();
}

public class PrintableTest implements Printable {
	public static void main(String[] args) {
//		new Printable();
		new PrintableTest();
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}
	
}
