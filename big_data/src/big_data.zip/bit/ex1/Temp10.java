package big_data.bit.ex1;

import java.util.Random;

public class Temp10 {
	Temp10(){
		this("no name");
		System.out.println("no argument");
	}
	String name;

	public Temp10(String name) {
		this.name = name;
	}
}
