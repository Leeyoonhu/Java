package big_data.bit.ex1;

public class ForEx {
	public static void main(String[] args) {
//		System.out.println(0);
//		System.out.println(1);

		for (int i = 0; i < 10; i++) { // 반복횟수 10번
			System.out.println(i);
		}
	}
}
