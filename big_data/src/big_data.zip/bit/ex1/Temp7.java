package big_data.bit.ex1;

public class Temp7 {
	public static void main(String[] args) {
		
	}
	public enum Size{
		SMALL("S"), MEDIUM("M"), LARGE("L");
		
		String abb;
		
		Size(String abb) {
			// TODO Auto-generated constructor stub
			this.abb = abb;
		}
		
	}

	
	
}
