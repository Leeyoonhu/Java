package big_data.bit.ex1;

public class ForEx01 {
	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) { // 반복횟수를 변수 i에 저장
			// 변수초기화 반복조건 반복동안할것
			System.out.println("반복문 연습" + (i + 1));
			// 초기 > 조건 > 출력 > 증감 > 조건 > 출력 >.... 증감 > 조건 > false 탈출
		}

	}
}
