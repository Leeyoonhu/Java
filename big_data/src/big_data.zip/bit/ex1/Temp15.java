package big_data.bit.ex1;

import java.util.Stack;

public class Temp15 {
	public static void main(String[] args) {
		Stack<String> s1 = new Stack<>();
		s1.push("사과");
		s1.push("바나나");
		s1.push("젤리");
		System.out.println(s1.peek());
		System.out.println();
		
		System.out.println(s1.pop());
		System.out.println(s1.pop());
		System.out.println(s1.pop());
		
		Stack<Integer> i1 = new Stack<>();

		for(int i : i1) {
			
		}
	}
}
