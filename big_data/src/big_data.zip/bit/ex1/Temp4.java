package big_data.bit.ex1;

public class Temp4 {
	public static void main(String[] args) {
		int a = 0; 
		if(a < 1) {
			int b = 1;
			System.out.println(b);
		}
		else if(a >= 1 && a < 3) {
			int b = 2;
			System.out.println(b);
		}
		

	}
}
