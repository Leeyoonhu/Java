package big_data.bit.ex1;

public class Temp1 {
	public static void main(String[] args) {
		int a = 3;
		int b = 3;
		int c = 3;
		int d = 3;
//		System.out.println(a++);
//		System.out.println(a);
		a = b = c + d / 3 * 5;
		System.out.println(a + ", " + b + ", " + c);
	}
}
