package big_data.bit.ex1;

public class SwitchDemo {
	public static void main(String[] args) {
		int num = 2;
		switch (num) {
		case 1:	// if(num == 1)
			System.out.println("*");

		case 2:	// if(num == 2)
			System.out.println("*");

		case 3:
			System.out.println("*");

		default: // else
			System.out.println("*");
		}
	}
}
