package big_data.bit.ex1;

public class WhatIsThis {
	int value = 1;
	
	class Really {
		int value = 2;
		
		void show() {
			System.out.println(this.value);
		}
	}
}
