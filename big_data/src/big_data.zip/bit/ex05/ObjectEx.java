package big_data.bit.ex05;

class D {
	
}

public class ObjectEx {
	public static void main(String[] args) {
		D d = new D();
		
		System.out.println(d.toString());
	}
}
