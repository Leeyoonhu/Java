package big_data.bit.ex05;

public interface SerialDriver {
	// 인터페이스는 상수와 추상메서드로만 구현
	abstract void run(); // 추상 메서드 표현인 abstract 생략가능
	
}
