package big_data.bit.ex03;

import java.util.Scanner;

// 문자열을 입력받아서 값을 저장하는 문자형배열 만들기

public class Temp01 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int count = 0;
		
		for(int i = 0; ; i++) {
			String str = scan.next();
			String[] strArray = new String[count];
			strArray[i] = new String();
		
		}
	}
}
