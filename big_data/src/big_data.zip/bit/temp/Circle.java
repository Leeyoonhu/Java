package big_data.bit.temp;

public class Circle {
	private void secret() {
		System.out.println("비밀이다");
	}
	
	protected void findRadius() {
		System.out.println("반지름이 10.0 센티이다.");
	}
	
	public void findArea() {
		System.out.println("넖이는 (PI * r * r )이다");
	}
}
